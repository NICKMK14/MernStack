
const dotenv = require('dotenv');
const mongoose = require('mongoose');
const express = require('express');
const app = express();

dotenv.config({path:'./config.env'});
require('./db/conn');
app.use(express.json());
app.use(require('./router/auth'));


const PORT = process.env.PORT;
//const User = require('./model/userSchema');

const middelware=(req,res,next)=>{
    console.log(`Hello World`);
    next();
}
app.get('/', (req, res) => {
res.send(`Hello world from the server`);
});
app.get('/about',middelware, (req, res) => {
    console.log(`This is about me`);
    res.send(`Hello About world from the server`);
});
app.listen(PORT, () => {
console.log(`server is runnig at port no ${PORT}`);
})