
import { useState } from "react";
import "./App.css";
import BarChart from "./components/Barcharts";
import {UserData} from './Data';


function Operation() {
const [userData, setUserData] = useState({
labels: UserData.map((data)=data.year),
datasets: [{
    labels:"User Gained",
    data:UserData.map((data)=data.userGain),
}]
})
return (
<div className="App">
<BarChart chartData={userData}/>
</div>
);
}
export default Operation;